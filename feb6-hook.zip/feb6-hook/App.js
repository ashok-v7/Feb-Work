import './index.css';
import SetUp from './UseStateArray'
function App() {
  return (
    <div className="container">
      <SetUp></SetUp>
       
    </div>
  );
}

export default App;