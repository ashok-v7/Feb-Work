export const data=[
    {
        id:1,
         name:'cliton'
    },
    {
        id:2,
         name:'lincoln'
    },
    {
        id:3,
         name:'Michael'
    },
];