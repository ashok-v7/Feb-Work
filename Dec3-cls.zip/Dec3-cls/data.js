export const data=[
    {
        id:1,
         name:'Navin'
    },
    {
        id:2,
         name:'Sanjeevan'
    },
    {
        id:3,
         name:'Hyder'
    },
];
